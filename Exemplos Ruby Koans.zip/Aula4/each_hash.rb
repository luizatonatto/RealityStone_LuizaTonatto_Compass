aulas = {"Aula 1" =>"liberada", "Aula 2" => "liberada", "Aula 3" => "liberada", "Aula 4 " => "liberada", "Aula 5" => "Em Breve"}

aulas.each do |key, value|
    puts "#{key} #{value}"
end