nomes = ["Joao", "Paulo", "Lucas" ]

nome = "Leonardo"

nomes.each do |nome|
    puts nome
end

puts nome