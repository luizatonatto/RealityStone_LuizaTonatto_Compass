#saidá de dado
print "Digite o seu nome: "

#Recebendo uma entrada do teclado
name = gets.chomp

print "Digite o seu nome: "

sobrenome = gets.chomp


#saida utilizando puts
#use codigos ruby dentro de uma string com #{code}
puts"Hello #{name}" "#{sobrenome}!"