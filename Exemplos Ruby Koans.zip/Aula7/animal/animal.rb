class Animal
    def pular
        puts "Toing! tóim! bóim! póim!"
    end

    def dormir
        puts "zzzzzz"
    end
end