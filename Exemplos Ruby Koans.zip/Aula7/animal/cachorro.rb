class Cachorro < Animal
    def latir
        puts "Au Au"
    end
end