def foo
    #Pode ser definido como local ou _local
    local = "local é acessado apenas dentro deste metodo"
    print local
end

foo