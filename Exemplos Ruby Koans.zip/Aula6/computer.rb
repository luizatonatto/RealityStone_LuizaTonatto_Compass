class Computer
    def ligar
        "Ligar o Computador"
    end

    def desligar
        "Desligar o Computador"
    end
end

computer = Computer.new
puts computer.desligar

