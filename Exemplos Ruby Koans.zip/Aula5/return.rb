def retorno
    "Hello"
end

puts retorno