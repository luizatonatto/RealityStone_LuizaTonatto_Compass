dia = "Domingo"

if dia == "Domingo"
    almoço = "Especial"
    
else
    almoço = "Normal"
    
end

puts " O almoço é #{almoço} hoje!!"