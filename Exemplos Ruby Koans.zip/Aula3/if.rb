dia = "Domingo"

if dia == "Domingo"
    almoço = "Especial"
end 

puts " O almoço é #{almoço} hoje!!"


