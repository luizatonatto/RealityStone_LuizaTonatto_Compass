dia = "feriado"

if dia == "Segunda"
    almoço = "Especial"
elsif dia == "Feriado"
    almoço = "Mais tarde"
else
    almoço = "Normal"
end

puts "O almoço é #{almoço} hoje"


