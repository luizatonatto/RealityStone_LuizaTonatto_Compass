frutas = {"Maça", "uva", "Morango" }

for fruta in frutas
    puts fruta
end 