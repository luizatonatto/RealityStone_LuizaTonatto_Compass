x = 1

while x < 10
    puts x 
    #Adiciona + 1 ao valor de x
    x += 1
end 