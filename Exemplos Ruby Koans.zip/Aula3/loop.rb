contar = 1

loop do
    puts contar 
    break if contar == 10
    #Incrementa a variável contar
    contar == 1
end

