10.times do
    puts "hello"
end